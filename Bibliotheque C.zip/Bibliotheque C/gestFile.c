#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include "init.h"

void CreateFile(Program* startup){
    system("cls");
    printf("           ------- Dictionnaire C -------\n------- Gestion des fichiers dictionnaire -------\n      ------- Creer un dictionnaire -------\n\n");
    printf("Nom du fichier : ");
    scanf("%s", (char*)startup->loadedFileName);
    strcat((char*)startup->loadedFileName, ".txt");
    startup->f = fopen((char*)startup->loadedFileName, "a+");
    rewind(startup->f);
    system("cls");
}

void LoadFile(Program* startup){
    system("cls");
    printf("           ------- Dictionnaire C -------\n------- Gestion des fichiers dictionnaire -------\n     ------- Charger un dictionnaire -------\n\n");
    printf("Nom du fichier : ");
    scanf("%s", (char*)startup->loadedFileName);
    strcat((char*)startup->loadedFileName, ".txt");
    FILE* f = fopen((char*)startup->loadedFileName, "r+");
    if(f == NULL){
        *startup->loadedFileName = NULL;
        system("cls");
        printf("/!\\ : Fichier non trouve, veuillez reessayer.\n\n");
        fclose(f);
        return;
    }else if(IsFileEmpty(f) == 1){
        *startup->loadedFileName = NULL;
        system("cls");
        printf("/!\\ : Fichier vide, veuillez essayer un autre fichier.\n\n");
        fclose(f);
        return;
    }else{
        fclose(f);
        startup->f = fopen((char*)startup->loadedFileName, "a+");
        rewind(startup->f);
        CleanDico(startup);
        FillDicoFromFile(startup);
    }
    system("cls");
}

void DeleteFile(Program* startup){
    system("cls");
    char* nameFile = malloc(sizeof(char) * 100);
    printf("           ------- Dictionnaire C -------\n------- Gestion des fichiers dictionnaire -------\n    ------- Supprimer un dictionnaire -------\n\n");
    printf("Nom du fichier : ");
    scanf("%s", nameFile);
    strcat(nameFile, ".txt");
    int checkDelete = remove(nameFile);
    if (checkDelete == -1){
        system("cls");
        printf("/!\\ : Le fichier dictionnaire n'existe pas.\n\n");
        return;
    }
    system("cls");
    printf("/!\\ : Le fichier dictionnaire a ete detruit.\n\n");
    free(nameFile);
    return;
}

int IsFileEmpty(FILE *file){
    fseek(file, 0, SEEK_END);
    if (ftell(file) == 0){
        return 1;
    }
    return 0;
}
