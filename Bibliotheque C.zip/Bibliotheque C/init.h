#ifndef INIT_H_INCLUDED
#define INIT_H_INCLUDED

#define INIT_CAPACITY 30000

struct Library {
	char letter; //Premi�re lettre des mots du tableau
	int capacity;
	int size; //Taille du dictionnaire
	char** words; //Tableau de mots
};

typedef struct Library Lib;


struct Program {
	char* loadedFileName[100];
	FILE* f;
	Lib* dictionary;
	int totalWords;
};

typedef struct Program Program;

//Protorypes main.c
Program* InitMain();
void FileMenu(Program*);
void DicoMenu(Program*);

//Protorypes main.c
Program* InitMain();
void FileMenu(Program*);
void DicoMenu(Program*);

//Prototypes gestFile.c
void CreateFile(Program*);
void LoadFile(Program*);
void DeleteFile(Program*);
int IsFileEmpty(FILE*);

//Prototypes gestBib.c
//  - Load Lib
void InitLibrary(Program*);
void FillDicoFromFile(Program*);
void FillDico(Program*);
//  - Lib's operations
void CleanDico(Program*);
void SortDico(Program*);
void OverrideCapacity(Program*, int);
void ToLowerCase(char*);
void SearchWord(Program*);
int GetIndexOf(Program*, int, char*);
void CountTotalWords(Program*);

//Prototypes gestBib.c


#endif // INIT_H_INCLUDED
