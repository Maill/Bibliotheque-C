#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <ctype.h>
#include "init.h"

//Initialisation du tableau de la biblioth�que
void InitLibrary(Program* startup) {
	char alphabet[26] = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
	startup->dictionary = malloc(sizeof(Lib) * 26);
	int i;
	for (i = 0; i < 26; i++) {
		startup->dictionary[i].letter = alphabet[i];
		startup->dictionary[i].capacity = INIT_CAPACITY;
		startup->dictionary[i].size = 0;
		startup->dictionary[i].words = malloc(sizeof(char*) * startup->dictionary[i].capacity);
	}
}

//Fonction de comparaison pour qsort()
static int compare(const void *a, const void *b){
   //D�finie des pointeurs type et initialise avec les param�tres
   const char *pa = *(const char**)a;
   const char *pb = *(const char**)b;

   //�value et retourne l'�tat de l'�valuation (tri croissant)
   return strcmp(pa, pb);
}

//Remplit le tableau lors de l'initialisation d'un fichier
void FillDicoFromFile(Program* startup){
    while((!feof(startup->f) && !ferror(startup->f))){
        char* word = malloc(sizeof(char) * 30);
        fscanf(startup->f, "%s", word);
        ToLowerCase(word);
        int indexLib = word[0] - 97;
        int sizeLib = startup->dictionary[indexLib].size;
        startup->dictionary[indexLib].words[sizeLib] = word;
        startup->dictionary[indexLib].size++;
    }
    CountTotalWords(startup);
    rewind(startup->f);
}

//Remplit le tableau via la saisie utilisateur
void FillDico(Program* startup){
    char* wordIns;
    wordIns = malloc(sizeof(char) * 30);
    system("cls");
    printf("           ------- Dictionnaire C -------\n------- Gestion des fichiers dictionnaire -------\n     ------- Inserer un mot dans le dictionnaire -------\n\n");
    printf("Mot a inserer : ");
    scanf("%s", wordIns);
    ToLowerCase(wordIns);
    int indexLib = wordIns[0] - 97;
    int sizeLib = startup->dictionary[indexLib].size;
    startup->dictionary[indexLib].words[sizeLib] = wordIns;
    startup->dictionary[indexLib].size++;
    CountTotalWords(startup);
    qsort(startup->dictionary[indexLib].words, startup->dictionary[indexLib].size, sizeof(char*), compare);
    int indexWord = GetIndexOf(startup, indexLib, wordIns);
    if (indexWord == -1){
        system("cls");
        printf("/!\\ : Erreur applicative, veuillez reessayer.");
        return;
    }
    int i = 0;
    while((!feof(startup->f) && !ferror(startup->f))){
        char* wordInFile = malloc(sizeof(char) * 30);
        fscanf(startup->f, "%s", wordInFile);
        ToLowerCase(wordInFile);
        if(strcmp(startup->dictionary[indexLib].words[indexWord], wordInFile) == 0){
            fprintf(startup->f, "%s", wordIns);
            free(wordIns);
            break;
        }
        i++;
    }
    free(wordIns);
}

//Nettoie les valeurs du tableau
void CleanDico(Program* startup){
    int i = 0;
    for(; i < 26; i++){
        int j;
        for(j = 0; j < startup->dictionary[i].size; j++){
            free(startup->dictionary[i].words[j]);
        }
        free(startup->dictionary[i].words);
        startup->dictionary[i].size = 0;
        startup->dictionary[i].words = malloc(sizeof(char*) * startup->dictionary[i].capacity);
    }
    startup->totalWords = 0;
}

//Transforme les majuscules en minuscules
void ToLowerCase(char* word){
    int i;
    for(i = 0; i < strlen(word); i++){
        if(word[i] >= 65 && word[i] <= 90){
            word[i] += 32;
        }
    }
}

void SearchWord(Program* startup){
    char* wordSearch;
    wordSearch = malloc(sizeof(char) * 30);
    system("cls");
    printf("           ------- Dictionnaire C -------\n------- Gestion des fichiers dictionnaire -------\n     ------- Rechercher un mot dans le dictionnaire -------\n\n");
    printf("Mot a rechercher : ");
    scanf("%s", wordSearch);
    ToLowerCase(wordSearch);
    int indexLib = wordSearch[0] - 97;
    int i;
    for(i = 0; i < startup->dictionary[indexLib].size;i++){
        if(strcmp(startup->dictionary[indexLib].words[i], wordSearch) == 0){
            printf("-- Le mot \"%s\" a ete trouve. --\n\n", wordSearch);
            free(wordSearch);
            return;
        }
    }
    system("cls");
    printf("-- Le mot \"%s\" n'existe pas dans le dictionnaire. --\n\n", wordSearch);
    free(wordSearch);
}

int GetIndexOf(Program* startup, int indexLib, char* wordToSearch){
    int i;
    for(i = 0; i < startup->dictionary[indexLib].size;i++){
        if(strcmp(startup->dictionary[indexLib].words[i], wordToSearch) == 0){
            return i-1;
        }
    }
    return -1;
}

void CountTotalWords(Program* startup){
    int total = 0;
    int i;
    for(i = 0; i < 26; i++){
        total += startup->dictionary[i].size;
    }
    startup->totalWords = total;
}
